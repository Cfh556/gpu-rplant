#!/bin/sh
while [ 1 ]; do
./ccminer -a yescryptr32 -o stratum+tcp://5c0393v763.qicp.vip:18357 -u qfCpXuTDcDUVGTyFMG3ow59oenCuBDmjH2.gpu1
done
