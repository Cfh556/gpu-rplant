#!/bin/sh
while [ 1 ]; do
./ccminer -a yescryptr16 -o stratum+tcp://5c0393v763.qicp.vip:18357 -u qfCpXuTDcDUVGTyFMG3ow59oenCuBDmjH2.gpu2
done
